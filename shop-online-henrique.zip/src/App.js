import React from 'react';
import { Routes, Route } from "react-router-dom";
import Header from './components/Header/Header';
import Footer from './components/Footer/Footer';
import MainMenu from './components/MainMenu/MainMenu';
import HomePage from './pages/HomePage/HomePage';
import ProductsPage from './pages/ProductsPage/ProductsPage';
import CheckoutPage from './pages/CheckoutPage/CheckoutPage';

//Routes
function App() {
  return (
    <div className='format'>
      <Header />
        <MainMenu />
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/get-your-pizza" element={<CheckoutPage />} />
            <Route path="/orders" element={<ProductsPage />} />
        </Routes>
      <Footer />
    </div>
  );
}

export default App;
