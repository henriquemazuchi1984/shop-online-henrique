import './Header.scss';
import { GiFullPizza } from 'react-icons/gi';

//Header Details + React Icon
function Header() {
    return (
        <header>
            <div className='title'>
                <GiFullPizza size={90}/><strong>One Free</strong> Pizza 
            </div>    
        </header>
    );
}

export default Header;