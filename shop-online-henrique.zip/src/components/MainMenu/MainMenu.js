import './MainMenu.scss';
import { NavLink } from "react-router-dom";

//MainMenu - Navigation
function MainMenu() {
    return (
        <nav>
            <NavLink to="/">Home</NavLink>
            <NavLink to="/get-your-pizza">Your Free Pizza</NavLink>
            <NavLink to="/orders">Order</NavLink>
        </nav>
    );
}

export default MainMenu;