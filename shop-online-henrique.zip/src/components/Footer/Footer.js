import './Footer.scss';

//Footer Details
function Footer(props) {
//Month and Day not in use -> optional for future use
    //const month = now.getMonth();
    //const day = now.getDay();
    const now = new Date();    
    const year = now.getFullYear();

    return (
        <footer>
         JS Major Project by Henrique Luiz Mazuchi - Copyright &copy; {year}.
        </footer>
    )
};

export default Footer;