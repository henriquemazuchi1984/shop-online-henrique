import { useEffect, useState } from "react";
import Product from './Product/Product';
import { useSelector, useDispatch } from 'react-redux';
import { setProducts } from './../../redux/productsSlice';
import api from './../../api';
import {BiLoaderCircle} from 'react-icons/bi';

function Products() {
	const products = useSelector((state) => state.products.list);
	const dispatch = useDispatch();

	const [loading, setLoading] = useState(true);
		
	useEffect(() => {
//API GET request
		api.get('/orders')
			.then((response) => {
				console.log('response', response);
				if (response.status === 200) {
					const products = response.data;
					dispatch(setProducts(products));
					setLoading(false);
				}
			});
	}, [dispatch]);

	return (
		<div>
			{loading && (
//React Icon
				<h3>
				Loading				
				<BiLoaderCircle size={50} color={'darkgray'}/>
				</h3>
			)}

			{products.map(
				(product, index) => {
					return (
						<Product
							key={index}
							product={product}
						/>
					);
				}
			)}
		</div>
	);
}

export default Products;