import './Product.scss';
import { removeProduct } from './../../../redux/cartSlice';
import { useDispatch } from 'react-redux';
import api from './../../../api';
import { useState } from "react";
import {IoMdRemoveCircleOutline} from 'react-icons/io';
import {MdRemoveCircle} from 'react-icons/md';

export default function Product(props) {
    const dispatch = useDispatch()
    const [formSubmited, setFormSubmited] = useState(false);
    const [saving, setSaving] = useState(false);

//API DELETE request
    const handleRemoveClick = () => {    
        const id = props.product.id;
            api.delete('/orders/' + id )
			.then((response ) => {
                if (response.status === 200) { 
                    dispatch(removeProduct(id));
                    setFormSubmited(true);
                }
                });
                setSaving(true);
    };

//Render + React Icon
    const renderSuccess = () => {
		return (
			<div className='success-submit'>
				<h2>Your order was Removed <MdRemoveCircle color={'red'}/></h2>
                
			</div>
		);
        }
    
//Render GET request
const renderForm = () => {
    return (
        <form onSubmit={handleRemoveClick}>
        <div>
            <div className='product-item'>
                <div className="card">
                    <div className="card-body">
                        <h5 className="card-title">{props.product.name}</h5>
                        
                        <p className="card-text">Your address:  {props.product.address} </p>
                        <p className="card-text">Pizza Style:  {props.product.style}</p>
                        <p className="card-text">Pizza Crust:  {props.product.crust}</p>
                        <p className="card-text">Order #:  {props.product.id}</p>
                        
                        <button type='submit'>Remove Order</button>
                    </div>
                </div>
            </div>
        </div>
        </form>
    );
}

//Render + React Icon
const renderSaving = () => {
    return (
        <h3>Removing Order<IoMdRemoveCircleOutline size={40} color={'red'}/></h3>
    );
}

if (formSubmited) {
    return renderSuccess();
}
else if (saving) {
    return renderSaving();
}

else {
    return renderForm();
}

}
