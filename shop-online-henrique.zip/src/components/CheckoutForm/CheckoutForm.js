//uui -> comment out for future use
//import uuid from 'react-uuid';
import { useState } from 'react';
import './CheckoutForm.scss';
import api from './../../api';
import {BiLoaderCircle} from 'react-icons/bi';
import {BiCheckDouble} from 'react-icons/bi';

export default function CheckoutForm() {	
	const [style, setStyle] = useState('');
	const [crust, setCrust] = useState('');
	const [cheese, setExtracheese] = useState(false);
	const [name, setUserName] = useState('');
	const [address, setUseraddress] = useState('');
	const [errorMessage, setErrorMessage] = useState(null);
	const [formSubmited, setFormSubmited] = useState(false);
	const [saving, setSaving] = useState(false);

//Replacing uuid to generate 10 digit ID number
	const ID = () => {
		return 'OD_' + Math.random().toString(36).substr(2, 7);
	};

	const handleUserNameChange = (event) => {
		const value = event.target.value;
		setUserName(value);
	}

	const handleUserAddress = (event) => {
		const value = event.target.value;
		setUseraddress(value);
	}

	const handleStyle = (event) => {
		const value = event.target.value;
		if (value === '') {
			alert('You must choose your Style');
		}
		else {
			setStyle(value);
		}
	}

	const handleCrust = (event) => {
		const value = event.target.value;
		if (value === '') {
			alert('You must select your Crust');
		}
		else {
			setCrust(value);
		}
	}

	const handleExtraCheese = (event) => {
		const value = event.target.checked;
		setExtracheese(value);
	}

//Error messages
	const handleSubmitForm = (event) => {
		event.preventDefault();
		let errors = [];
		if (style === '') {
			errors.push('Choose your Style !');
		}

		if (crust === '') {
			errors.push('Select your Crust !');
		}

		if (name === '') {
			errors.push('You must enter your NAME');
		}

		if (address === '') {
			errors.push('you must enter your ADDRESS');
		}

// Check for error
		if (errors.length > 0) {
			setErrorMessage(errors);
		}
		else {

//JSON data
			let data = {
				//uuid replace for ID -> keep uuid for future use
				//id: uuid(),
				id: ID(),
				style: style,
				crust: crust,
				cheese: cheese,
				name: name,
				address: address,
			};

//Saving Statement
			setSaving(true);

//API POST request
			api.post('/orders', data)
				.then((response) => {
					console.log(response);
					if (response.status === 201) {
						setErrorMessage(null);
						setFormSubmited(true);
					}
				});
		}
	}

//Render + React Icon
	const renderSuccess = () => {
		return (
			<div className='success-submit'>
				<strong>Success </strong>
				<div>
				<h3>Your order was submitted
						<BiCheckDouble size={50} color={'green'} />
				</h3></div>
			</div>
			
		);
	}

	const renderForm = () => {
		const extracheeseStyle = {
			color: cheese
				? 'green' 
				: 'black'
		};

		return (
			<div>
			<form onSubmit={handleSubmitForm}>
				{errorMessage && (
					<div className='error'>
						Please, verify missing data:
						<ul>
							{errorMessage.map(
								(error, index) => (
									<li key={index}>{error}</li>
								)
							)}
						</ul>
					</div>
				)}

				<label>
				<span>STYLE</span>
					<select
						value={style}
						onChange={handleStyle}
					>
						<option value=""></option>
						<option value="Hawaiian">Hawaiian</option>
						<option value="Pepperoni">Pepperoni</option>
						<option value="Canadian">Canadian</option>
						<option value="Supreme">Supreme</option>
						<option value="Cheese">Cheese</option>
						<option value="Margherita">Margherita</option>
						
					</select>
				</label>

				<label>
				<span>CRUST</span>
					<select
						value={crust}
						onChange={handleCrust}
					>
						<option value=""></option>
						<option value="Original Crust">Original Crust</option>
						<option value="Thin Crust">Thin Crust</option>
						<option value="Gluten-Free Crust">Gluten-Free Crust</option>
						<option value="Stuffed Cheddar">Stuffed Cheddar</option>
						<option value="Stuffed Cheese">Stuffed Cheese</option>
					</select>
				</label>

				<label style={extracheeseStyle}>
					<input
						type="checkbox"
						checked={cheese}
						onChange={handleExtraCheese}
					/>
					Add Extra Cheese
				</label><br />
				
				<label>
					<span>User Name:</span>
					<input
						type="text"
						maxLength="50"
						value={name}
						onChange={handleUserNameChange}
					/>
				</label>

				<label>
					<span>Your Address:</span>
					<input
						type="text"
						maxLength="200"
						value={address}
						onChange={handleUserAddress}
					/>
				</label>
				<button classname="button" onClick>Send order</button>
			</form>
			</div>	
		);	
	}
	
//Render + React Icon
	const renderSaving = () => {
		return (
			<h3>
				Sending Order
				<BiLoaderCircle size={50} color={'darkgray'}/>
			</h3>
		);
	}

	if (formSubmited) {
		return renderSuccess();
	}
	else if (saving) {
		return renderSaving();
	}
	else {
		return renderForm();
	}

}

