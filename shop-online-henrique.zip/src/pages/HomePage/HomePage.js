import '../../components/MainMenu/MainMenu.scss';

//HomePage Message
function HomePage() {   
    return (
        <main>
            <h1>Welcome</h1>
            <h4>
            <br />
                One Free Pizza is giving a FREE PIZZA to all our customers.
                Please, use the menu above to get yours ! 
            <br /><br />
                We take our job very serious. Our main influence comes from the famuos "Mooca" district, São Paulo-Brazil,
            <br />well know
                for its Italian roots and lots of amazing restaurants.
            <br /><br />
                Hope you can enjoy it.
            <br /><br />
                Please, do not order more than once.
                We Trust You !
            <br /><br />
                All the best !
            <br />
                One Free Pizza Team
            </h4>
        </main>      
        
    );
}

export default HomePage;