import CheckoutForm from "../../components/CheckoutForm/CheckoutForm";

//Checkout Page -> API POST request
export default function CheckoutPage() {
    return (        
        <main>
            <h1>Submit Order</h1>
            <CheckoutForm />  
        </main>        
    );
}
