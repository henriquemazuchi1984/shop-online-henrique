import Products from '../../components/Products/Products';

//Order Page -> API GET request
function ProductsPage() {
    return (
        <main>
            <h1>Your Order</h1>
            <Products/>
        </main>
    );
}

export default ProductsPage;