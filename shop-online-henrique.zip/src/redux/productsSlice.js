import { createSlice } from '@reduxjs/toolkit';

const initialState = {
    list: [],
}

export const productsSlice = createSlice({
    name: 'products',
    initialState,
    reducers: {
        setProducts: (state, action) => {
            state.list = action.payload;
        }
    },
});

export default productsSlice.reducer;
export const { setProducts } = productsSlice.actions;