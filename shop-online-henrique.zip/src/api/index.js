import axios from 'axios';

//API Detail
const instance = axios.create({
    baseURL: 'https://9cxlt1wgo5.execute-api.us-east-1.amazonaws.com/api',
    timeout: 6000,
    headers: {
        'Authorization': 'basic 71b79570-8f3c-45bb-82a3-dedc5cfc9fd8'
    }
});

export default instance;